##################################################
INFO
-----
Sunware V1.0.4 
Readme.txt
ALL COPYRIGHTS (c) TECHBYTES 2021-2023
OTHER SOFTWARES:
- Trojanbytes
- Sunware trainer
- Sunrise.cc
- Silvestras6969 crack
##################################################

##################################################
SOCIALS
--------
Discord: Aabox#0001
Gmail: Aapoxkurkix@gmail.com
Github: https://github.com/Aapoxi
##################################################


##################################################
UPDATES
--------
24.5.2023 - Sunware created.
1.6.2023 - Fixing bugs, Settings added
2.6.2023 - Exit application added
3.6.2023 - Better autocollect,fast pickup (no delay) ,binds added
4.6.2023 - Recoded whole proxy
5.6.2023 - Injector added (inject own dlls)
6.6.2023 - Fixed injector + bugs